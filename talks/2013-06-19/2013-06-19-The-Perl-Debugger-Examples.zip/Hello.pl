#!/usr/bin/perl

=pod

=head1 NAME

Hello.pl - Hello World example

=head1 SYNOPSIS

Hello.pl [-user <name>]

=cut

# Setup Pragmas.
use strict;
use warnings;
use English;

# Import common libaries.
use Getopt::Long;
use Pod::Usage;

sub main
{
    # Get command line arguments.
    my $opts=getArgs();

    if( exists $opts->{'user'} )
    {
        printf "Hello %s!\n", $opts->{'user'};
    }
    else
    {
        print "Hello World!\n";
    }

    return 0;
}

sub getArgs
{
    # Setup the raw options from the system defaults.
    my $raw_opts;
    $raw_opts->{'help'}    = sub{ pod2usage(-verbose=>0) };
    $raw_opts->{'man'}     = sub{ pod2usage(-verbose=>2, -exitstatus => 0 ) };

    # Use the store in hash form op GetOptions, with references to exceptions setup above.
    GetOptions( $raw_opts,
        'user=s',
    ) or pod2usage(-verbose=>0,  -message => "incorect options");

    # Filter out code reference options to reduce clutter when debugging
    my %ret_opts = map {$_=> $raw_opts->{$_} } grep{ 'CODE' ne ref $raw_opts->{$_} } keys %$raw_opts;
    return \%ret_opts;
}

exit main();


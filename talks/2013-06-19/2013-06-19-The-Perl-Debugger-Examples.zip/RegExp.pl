#!/usr/bin/perl

use Data::Dumper;

sub get_machines
{
    # parse /etc/ethers to get the list
    my %retHash;

    while (my $line = <DATA>)
    {
        my($mac, $ip, $name) = split /\s+/, $line;

        if( valid_ip($ip) )
        {
            $retHash{$name} = { 'mac'=>$mac, 'ip'=>$ip};
        }
    }

    return \%retHash;
}

sub valid_ip
{
    my $ip_addr = shift @_;

    if( $ip_addr =~ m/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/ )
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

my $ethers = get_machines();

print Dumper($ethers);

__DATA__

00:24:1d:cc:e5:f3 192.168.1.12 miranda
00:1a:4d:48:ac:e8 192.168.1.5  boris
00:08:9b:c0:f5:f9 192.168.1.20 jeeves
c8:60:00:58:7d:c9 192.168.1.50 jonah


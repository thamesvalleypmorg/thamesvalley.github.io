#!/usr/bin/perl

use Data::Dumper;
use HTML::Element;
use HTML::TreeBuilder;
use File::Slurp qw(read_file);

sub parseResPage
{
    my ( $rawHTML ) = @_;

    my $tree = HTML::TreeBuilder->new_from_content( $rawHTML );

    my @headings = $tree->look_down('_tag'=> 'tr', 'class'=>"post-head post_head");
    my $firstHeading = shift @headings;
    my $headText = $firstHeading->as_text();

    return $headText;
}

my $rawHTML = read_file('perlmonks.html');
my $results = parseResPage($rawHTML);
print Dumper($results);
